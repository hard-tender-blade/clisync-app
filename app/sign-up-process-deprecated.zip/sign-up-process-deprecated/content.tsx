'use client'
import React, { useState } from 'react'
import Link from 'next/link'
import {
    validateAddress,
    validateCity,
    validateEmail,
    validateName,
    validatePassword,
    validatePhoneNumber,
    validatePostalCode,
} from '@/modules/shared/validation/validation'
import { showAlert } from '@/modules/client/utils/alert/alerts'
import { FiInfo } from 'react-icons/fi'
import Timeline from './components/timeline'
import signUpWithEmailAndPassword from '@/modules/client/query/auth/singUp'
import languageInterface, { Language } from '@/modules/client/languageInterface/language'
import { useRouter, useSearchParams } from 'next/navigation'
import Step1 from './components/step1'
import Step2 from './components/step2'
import Step3 from './components/step3'
import Step4 from './components/step4'
import Step5 from './components/step5'
import { IoIosArrowBack } from 'react-icons/io'
import { FcGoogle } from 'react-icons/fc'
import { GoogleOAuthProvider } from '@react-oauth/google'
import publicConfig from '@/modules/shared/config/publicConfig'
import exist from '@/modules/client/query/auth/exist'
import GoogleButton from './components/googleButton'
import { GoogleAuthResponse } from '@/modules/shared/types/subTypes'

export default function Content({ lang: l }: { lang: Language }) {
    const [lang, setLang] = useState(l)
    const [LI, setLI] = useState(languageInterface.interfaces.signUp[l])

    const router = useRouter()
    const searchParams = useSearchParams()

    const [step, setStep] = useState(0)

    // Root
    const [email, setEmail] = useState('')
    const [password1, setPassword1] = useState('')
    const [password2, setPassword2] = useState('')

    // Person
    const [name, setName] = useState('')
    const [phoneNumber, setPhoneNumber] = useState('')

    // Job
    const [jobTitle, setJobTitle] = useState('')
    const [experience, setExperience] = useState(0)
    const [isClinicPsychologist, setIsClinicPsychologist] = useState(false)

    // Services
    const [onlineService, setOnlineService] = useState(false)
    const [inPersonService, setInPersonService] = useState(false)

    // Place
    const [country, setCountry] = useState('')
    const [city, setCity] = useState('')
    const [address, setAddress] = useState('')
    const [postalCode, setPostalCode] = useState('')

    // About me
    const [profilePictureUrl, setProfilePictureUrl] = useState('')
    const [aboutMe, setAboutMe] = useState('')
    const [status, setStatus] = useState(LI.step5.statuses.lookingForNewCustomers)
    const [website, setWebsite] = useState('')

    const [googleAccessToken, setGoogleAccessToken] = useState<string | null>()
    const [googleRefreshToken, setGoogleRefreshToken] = useState<string | null>()

    const goTo1Step = async () => {
        if (!validateEmail(email)) {
            showAlert('error', 'short', LI.root.errors.invalidEmail)
            return
        }

        if (!validatePassword(password1)) {
            showAlert('error', 'mid', LI.root.errors.weekPassword)
            return
        }

        if (password1 !== password2) {
            showAlert('error', 'short', LI.root.errors.passwordsNotMatch)
            return
        }

        const existUser = await exist(email)
        if (existUser) {
            showAlert('error', 'short', LI.root.errors.alreadyRegistered)
            return
        }

        setStep(1)
    }

    const goTo1StepWithGoogle = async (data: GoogleAuthResponse) => {
        const existUser = await exist(data.user.email)
        if (existUser) {
            showAlert('error', 'short', LI.root.errors.alreadyRegistered)
            return
        }

        setName(data.user.name)
        setEmail(data.user.email)
        setProfilePictureUrl(data.user.picture)

        setGoogleAccessToken(data.tokens.access_token)
        setGoogleRefreshToken(data.tokens.refresh_token)

        setStep(1)
    }

    const goTo2Step = () => {
        if (!validateName(name)) {
            showAlert('error', 'short', LI.step1.errors.invalidFullName)
            return
        }

        if (!validatePhoneNumber(phoneNumber)) {
            showAlert('error', 'short', LI.step1.errors.invalidPhoneNumber)
            return
        }

        setStep(2)
    }

    const goTo3Step = () => {
        if (jobTitle === '') {
            showAlert('error', 'short', LI.step2.errors.invalidJobTitle)
            return
        }

        if (experience < 0) {
            showAlert('error', 'short', LI.step2.errors.invalidExperienceYears)
            return
        }

        setStep(3)
    }

    const goTo4Step = () => {
        if (!onlineService && !inPersonService) {
            showAlert('error', 'short', LI.step3.errors.youShouldChooseAtLeastOne)
            return
        }

        setStep(4)
    }

    const goTo5Step = () => {
        if (!validateCity(city)) {
            showAlert('error', 'short', LI.step4.errors.invalidCity)
            return
        }

        if (!validateAddress(address)) {
            showAlert('error', 'short', LI.step4.errors.invalidAddress)
            return
        }

        if (!validatePostalCode(postalCode)) {
            showAlert('error', 'short', LI.step4.errors.invalidPostalCode)
            return
        }

        setStep(5)
    }

    const finish = () => {
        if (aboutMe.length < 0) {
            showAlert('error', 'short', LI.step5.errors.invalidAboutMe)
            return
        }

        if (status === '') {
            showAlert('error', 'short', LI.step5.errors.invalidStatus)
            return
        }

        handleSubmit()
    }

    const handleSubmit = async () => {
        //todo add validation
        const ok = await signUpWithEmailAndPassword({
            name,
            email,
            jobTitle,
            phoneNumber,
            city,
            experience,
            onlineService,
            inPersonService,
            status,
            isClinicPsychologist,
            website,
            password: password1,
            country,
            address,
            postalCode,
            aboutMe,
            lang,
            googleAccessToken: googleAccessToken || undefined,
            googleRefreshToken: googleRefreshToken || undefined,
        })

        if (ok) router.replace(`/`)
    }

    const handleLanguageChange = (event: any) => {
        router.push(`/${event.target.value}/sign-up?${searchParams.toString()}`)
    }

    const handleAccLanguageChange = (event: any) => {
        const newLang = event.target.value
        if (!languageInterface.check(newLang)) return
        setLang(newLang)
        setLI(languageInterface.interfaces.signUp[newLang])
    }

    return (
        <GoogleOAuthProvider clientId={publicConfig.next_public_google_client_id}>
            <div className="flex h-screen w-screen">
                <div
                    className={`h-screen bg-primary transition-all duration-300 ease-out ${step === 0 ? 'w-7/12' : 'w-0'}`}
                >
                    {/* //todo add image */}
                </div>

                <div
                    className={`max-h-screen transition-all duration-300 ease-out ${step === 0 ? 'hidden w-0' : 'w-4/12'}`}
                >
                    <Timeline lang={lang} currentStep={step} setStep={setStep} />
                </div>

                <div
                    className={`flex ${step === 0 ? 'w-5/12 justify-center' : 'w-8/12'} transition-all ease-out`}
                >
                    {step === 0 && (
                        <div className="flex w-8/12  flex-col gap-2 py-24">
                            <div className="flex items-center justify-between">
                                <h3 className="whitespace-nowrap text-3xl font-bold">
                                    {LI.root.title}
                                </h3>
                                <select
                                    className="select select-bordered select-xs"
                                    onChange={handleLanguageChange}
                                    value={lang}
                                >
                                    {languageInterface.supportedLanguages.map((sl) => (
                                        <option key={sl}>{sl}</option>
                                    ))}
                                </select>
                            </div>
                            <label className="form-control w-full">
                                <div className="label">
                                    <span className="label-text">{LI.root.email}</span>
                                </div>
                                <input
                                    type="text"
                                    placeholder="Email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="input input-bordered w-full"
                                    id="email-input"
                                    autoComplete="email"
                                />
                            </label>
                            <label className="form-control w-full">
                                <div className="label">
                                    <span className="label-text">{LI.root.password}</span>
                                </div>
                                <input
                                    type="password"
                                    placeholder={LI.root.password}
                                    value={password1}
                                    onChange={(e) => setPassword1(e.target.value)}
                                    className="input input-bordered w-full"
                                    id="password-input"
                                    autoComplete="current-password"
                                />
                            </label>
                            <label className="form-control w-full">
                                <div className="label">
                                    <span className="label-text">
                                        {LI.root.repeatPassword}
                                    </span>
                                </div>
                                <input
                                    type="password"
                                    placeholder={LI.root.repeatPassword}
                                    value={password2}
                                    onChange={(e) => setPassword2(e.target.value)}
                                    className="input input-bordered w-full"
                                    id="password-input"
                                    autoComplete="current-password"
                                />
                            </label>
                            <button className="btn btn-primary mt-6" onClick={goTo1Step}>
                                {LI.root.create}
                            </button>

                            <GoogleButton
                                title={'Sign up with Google'}
                                callBack={goTo1StepWithGoogle}
                                calendarScope={false}
                            />

                            {/* <button
                                className="btn btn-outline btn-neutral mt-4"
                                onClick={goTo1Step}
                            >
                                <FcGoogle className="h-8 w-8" />
                                Sign up with Google
                            </button> */}

                            <div className="divider text-sm uppercase">{LI.root.or}</div>

                            <Link href="/sign-in" className="btn">
                                {LI.root.alreadyHaveAcc}
                            </Link>
                        </div>
                    )}

                    {step !== 0 && (
                        <div className="flex w-8/12 max-w-xs flex-col gap-2 py-24">
                            <button
                                className="btn btn-sm flex w-fit items-center"
                                onClick={() => {
                                    if (step > 0) setStep(step - 1)
                                }}
                            >
                                <IoIosArrowBack />
                                Back
                            </button>
                            {step === 1 && (
                                <Step1
                                    LI={LI}
                                    lang={lang}
                                    name={name}
                                    setName={setName}
                                    phoneNumber={phoneNumber}
                                    setPhoneNumber={setPhoneNumber}
                                    goTo2Step={goTo2Step}
                                    handleAccLanguageChange={handleAccLanguageChange}
                                />
                            )}
                            {step === 2 && (
                                <Step2
                                    LI={LI}
                                    jobTitle={jobTitle}
                                    setJobTitle={setJobTitle}
                                    experience={experience}
                                    setExperience={setExperience}
                                    isClinicPsychologist={isClinicPsychologist}
                                    setIsClinicPsychologist={setIsClinicPsychologist}
                                    goTo3Step={goTo3Step}
                                />
                            )}
                            {step === 3 && (
                                <Step3
                                    LI={LI}
                                    onlineService={onlineService}
                                    setOnlineService={setOnlineService}
                                    inPersonService={inPersonService}
                                    setInPersonService={setInPersonService}
                                    goTo4Step={goTo4Step}
                                />
                            )}
                            {step === 4 && (
                                <Step4
                                    LI={LI}
                                    country={country}
                                    setCountry={setCountry}
                                    city={city}
                                    setCity={setCity}
                                    address={address}
                                    setAddress={setAddress}
                                    postalCode={postalCode}
                                    setPostalCode={setPostalCode}
                                    goTo5Step={goTo5Step}
                                />
                            )}
                            {step === 5 && (
                                <Step5
                                    LI={LI}
                                    status={status}
                                    setStatus={setStatus}
                                    aboutMe={aboutMe}
                                    setAboutMe={setAboutMe}
                                    website={website}
                                    setWebsite={setWebsite}
                                    finish={finish}
                                />
                            )}
                        </div>
                    )}
                </div>
            </div>
        </GoogleOAuthProvider>
    )
}
