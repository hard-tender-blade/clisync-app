import { showAlert } from '@/modules/client/utils/alert/alerts'
import { GoogleAuthResponse } from '@/modules/shared/types/subTypes'
import { useGoogleLogin } from '@react-oauth/google'
import React from 'react'
import { FcGoogle } from 'react-icons/fc'

export default function GoogleButton({
    title,
    callBack,
    calendarScope,
}: {
    title: string
    callBack: (data: GoogleAuthResponse) => void
    calendarScope: boolean
}) {
    const handleClick = useGoogleLogin({
        onSuccess: async ({ code }) => {
            const data = await authWithGoogle(code)
            if (!data) {
                showAlert(
                    'error',
                    'short',
                    'Failed to authenticate with Google, contact support please',
                )
                return
            }
            callBack(data)
        },
        onError: (error) => {
            showAlert(
                'error',
                'short',
                'Failed to authenticate with Google, contact support please',
            )
        },
        flow: 'auth-code',
        scope: calendarScope ? 'https://www.googleapis.com/auth/calendar' : undefined,
    })

    return (
        <button className="btn btn-outline btn-neutral mt-4" onClick={handleClick}>
            <FcGoogle className="h-8 w-8" />
            {title}
        </button>
    )
}
