import languageInterface from '@/modules/client/languageInterface/language'
import React from 'react'
import { FiInfo } from 'react-icons/fi'

export default function Step1({
    LI,
    lang,
    handleAccLanguageChange,
    name,
    setName,
    phoneNumber,
    setPhoneNumber,
    goTo2Step,
}: {
    LI: any
    lang: string
    handleAccLanguageChange: (e: any) => void
    name: string
    setName: (name: string) => void
    phoneNumber: string
    setPhoneNumber: (phoneNumber: string) => void
    goTo2Step: () => void
}) {
    return (
        <>
            <h3 className="text-3xl font-bold">{LI.step1.title}</h3>
            <label className="form-control w-full max-w-xs">
                <div className="label">
                    <span className="label-text">{LI.step1.language}</span>
                </div>
                <select
                    className="select select-bordered"
                    value={lang}
                    onChange={handleAccLanguageChange}
                >
                    {Object.keys(languageInterface.interfaces.signUp).map((l) => (
                        <option key={l}>{l}</option>
                    ))}
                </select>
            </label>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step1.fullName.label}</span>
                </div>
                <input
                    type="text"
                    placeholder={LI.step1.fullName.placeholder}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="input input-bordered"
                    id="name-input"
                    autoComplete="name"
                />
            </label>
            <label className="form-control w-full ">
                <div className="label">
                    <div className="flex items-center gap-2">
                        <span className="label-text">{LI.step1.phoneNumber.label}</span>
                        <div
                            className="lg:tooltip"
                            data-tip={LI.step1.phoneNumber.toolTip}
                        >
                            <FiInfo />
                        </div>
                    </div>
                </div>
                <input
                    type="text"
                    placeholder={LI.step1.phoneNumber.placeholder}
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="input input-bordered"
                    id="name-input"
                    autoComplete="name"
                />
            </label>
            <button className="btn btn-primary mt-6" onClick={goTo2Step}>
                {LI.shared.continue}
            </button>
        </>
    )
}
