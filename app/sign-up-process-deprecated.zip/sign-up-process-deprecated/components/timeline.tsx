import languageInterface, { Language } from '@/modules/client/languageInterface/language'
import React from 'react'
import { BsCheckCircleFill, BsCircle, BsCircleFill } from 'react-icons/bs'

export default function Timeline({
    lang,
    currentStep,
    setStep,
}: {
    lang: Language
    currentStep: number
    setStep: (value: number) => void
}) {
    const LI = languageInterface.interfaces.signUp[lang]

    const steps = [LI.step1, LI.step2, LI.step3, LI.step4, LI.step5]

    return (
        <ul className="timeline timeline-vertical h-screen pl-32">
            {steps.map((step, index) => {
                const first = index === 0
                const last = index === steps.length - 1
                const passed = currentStep > index + 1
                const current = currentStep === index + 1

                return (
                    <li
                        key={index}
                        className={`${first && 'h-44'} transition-all duration-300 ease-out`}
                    >
                        <hr
                            className={`${currentStep > index && 'bg-primary'} transition-all duration-300 ease-out`}
                        />
                        <button
                            className={`timeline-start my-5 whitespace-nowrap transition-all duration-300 ease-out ${passed && 'hover:underline'} ${current && 'text-xl font-bold'} ${!passed && !current && 'opacity-30'}`}
                            disabled={!passed && !current}
                            onClick={() => setStep(index + 1)}
                        >
                            {step.title}
                        </button>
                        <div className="timeline-middle">
                            {passed ? (
                                <BsCheckCircleFill className="m-1 h-4 w-4 text-primary transition-all duration-300 ease-out" />
                            ) : (
                                <BsCircleFill
                                    className={`m-1 opacity-20 transition-all duration-300 ease-out  ${current && 'h-7 w-7'} `}
                                />
                            )}
                        </div>
                        {!last && <hr className={`${passed && 'bg-primary'}`} />}
                    </li>
                )
            })}
        </ul>
    )
}
