import React from 'react'

export default function Step2({
    LI,
    jobTitle,
    setJobTitle,
    experience,
    setExperience,
    isClinicPsychologist,
    setIsClinicPsychologist,
    goTo3Step,
}: {
    LI: any
    jobTitle: string
    setJobTitle: (value: string) => void
    experience: number
    setExperience: (value: number) => void
    isClinicPsychologist: boolean
    setIsClinicPsychologist: (value: boolean) => void
    goTo3Step: () => void
}) {
    return (
        <>
            <h3 className="text-3xl font-bold">{LI.step2.title}</h3>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step2.jobTitle.label}</span>
                </div>
                <input
                    type="text"
                    placeholder={LI.step2.jobTitle.placeholder}
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    className="input input-bordered"
                    id="job-title-input"
                    autoComplete="organization-title"
                />
            </label>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step2.experienceYears}</span>
                </div>
                <input
                    type="number"
                    value={experience}
                    onChange={(e) =>
                        setExperience(
                            Number(e.target.value) > -1 ? Number(e.target.value) : 0,
                        )
                    }
                    className="input input-bordered"
                    id="experience-input"
                />
            </label>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step2.clinicPsychologist}</span>
                </div>
                <input
                    type="checkbox"
                    checked={isClinicPsychologist}
                    onChange={(e) => setIsClinicPsychologist(e.target.checked)}
                    className="toggle"
                    id="clinic-psychologist"
                />
            </label>
            <button className="btn btn-primary mt-6" onClick={goTo3Step}>
                {LI.shared.continue}
            </button>
        </>
    )
}
