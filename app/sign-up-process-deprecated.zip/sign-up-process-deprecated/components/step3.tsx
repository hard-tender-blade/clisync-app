import React from 'react'

export default function Step3({
    LI,
    onlineService,
    setOnlineService,
    inPersonService,
    setInPersonService,
    goTo4Step,
}: {
    LI: any
    onlineService: boolean
    setOnlineService: (value: boolean) => void
    inPersonService: boolean
    setInPersonService: (value: boolean) => void
    goTo4Step: () => void
}) {
    return (
        <>
            <h3 className="text-3xl font-bold">{LI.step3.title}</h3>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step3.onlineServices}</span>
                </div>
                <input
                    type="checkbox"
                    checked={onlineService}
                    onChange={(e) => setOnlineService(e.target.checked)}
                    className="toggle"
                    id="online-services"
                />
            </label>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step3.inPersonServices}</span>
                </div>
                <input
                    type="checkbox"
                    checked={inPersonService}
                    onChange={(e) => setInPersonService(e.target.checked)}
                    className="toggle"
                    id="in-person-service"
                />
            </label>

            <button className="btn btn-primary mt-6" onClick={goTo4Step}>
                {LI.shared.continue}
            </button>
        </>
    )
}
