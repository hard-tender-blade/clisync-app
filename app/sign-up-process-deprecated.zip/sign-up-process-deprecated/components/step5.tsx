import React from 'react'
import { FiInfo } from 'react-icons/fi'
import { SignUp } from '@/modules/client/languageInterface/interfaces/signUp'

export default function Step5({
    LI,
    status,
    setStatus,
    aboutMe,
    setAboutMe,
    website,
    setWebsite,
    finish,
}: {
    LI: SignUp
    status: string
    setStatus: (value: string) => void
    aboutMe: string
    setAboutMe: (value: string) => void
    website: string
    setWebsite: (value: string) => void
    finish: () => void
}) {
    return (
        <>
            <h3 className="text-3xl font-bold">{LI.step5.title}</h3>
            <label className="form-control w-full">
                <div className="label">
                    <div className="flex items-center gap-2">
                        <span className="label-text">{LI.step5.status.label}</span>
                        <div className="lg:tooltip" data-tip={LI.step5.status.toolTip}>
                            <FiInfo />
                        </div>
                    </div>
                </div>
                <select
                    className="select select-bordered"
                    value={status}
                    onChange={(e) => {
                        setStatus(e.target.value)
                    }}
                >
                    {Object.values(LI.step5.statuses).map((l) => (
                        <option key={l}>{l}</option>
                    ))}
                </select>
                {/* <details className="dropdown w-full">
                    <summary id="sum" className="btn btn-outline w-full">
                        {status}
                    </summary>
                    <ul className="menu dropdown-content z-[1] rounded-box bg-base-100 p-2 shadow">
                        {Object.values(LI.step5.statuses).map((status) => (
                            <li key={status}>
                                <a
                                    onClick={() => {
                                        setStatus(status)
                                        // click on summary to close dropdown
                                        document.getElementById('sum')?.click()
                                    }}
                                >
                                    {status}
                                </a>
                            </li>
                        ))}
                    </ul>
                </details> */}
            </label>
            <label className="form-control w-full">
                <div className="label">
                    <div className="flex items-center gap-2">
                        <span className="label-text">{LI.step5.aboutMe.label}</span>
                        <div className="lg:tooltip" data-tip={LI.step5.aboutMe.toolTip}>
                            <FiInfo />
                        </div>
                    </div>
                </div>
                <textarea
                    placeholder={LI.step5.aboutMe.placeholder}
                    value={aboutMe}
                    onChange={(e) => setAboutMe(e.target.value)}
                    className="textarea input-bordered"
                    id="about-me-input"
                />
            </label>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step5.website.label}</span>
                </div>
                <input
                    type="text"
                    placeholder={LI.step5.website.placeholder}
                    value={website}
                    onChange={(e) => setWebsite(e.target.value)}
                    className="input input-bordered"
                    id="website-input"
                />
            </label>
            <button className="btn btn-primary mt-6" onClick={finish}>
                {LI.step5.finishRegistration}
            </button>
        </>
    )
}
