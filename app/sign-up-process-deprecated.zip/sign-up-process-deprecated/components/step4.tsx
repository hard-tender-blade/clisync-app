import { SignUp } from '@/modules/client/languageInterface/interfaces/signUp'
import React from 'react'

export default function Step4({
    LI,
    country,
    setCountry,
    city,
    setCity,
    address,
    setAddress,
    postalCode,
    setPostalCode,
    goTo5Step,
}: {
    LI: SignUp
    country: string
    setCountry: (value: string) => void
    city: string
    setCity: (value: string) => void
    address: string
    setAddress: (value: string) => void
    postalCode: string
    setPostalCode: (value: string) => void
    goTo5Step: () => void
}) {
    return (
        <>
            <h3 className="text-3xl font-bold">{LI.step4.title}</h3>
            <select
                className="select select-bordered"
                value={country}
                onChange={(e) => {
                    setCountry(e.target.value)
                }}
            >
                {LI.step4.countries.sort().map((l) => (
                    <option key={l}>{l}</option>
                ))}
            </select>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step4.city.label}</span>
                </div>
                <input
                    type="text"
                    placeholder={LI.step4.city.placeholder}
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="input input-bordered"
                    id="city-input"
                    autoComplete="address-level2"
                />
            </label>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step4.address.label}</span>
                </div>
                <input
                    type="text"
                    placeholder={LI.step4.address.placeholder}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="input input-bordered"
                    id="address-input"
                    autoComplete="street-address"
                />
            </label>
            <label className="form-control w-full">
                <div className="label">
                    <span className="label-text">{LI.step4.postalCode.label}</span>
                </div>
                <input
                    type="text"
                    placeholder={LI.step4.postalCode.placeholder}
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="input input-bordered"
                    id="postal-code-input"
                    autoComplete="postal-code"
                />
            </label>
            <button className="btn btn-primary mt-6" onClick={goTo5Step}>
                {LI.shared.continue}
            </button>
        </>
    )
}
